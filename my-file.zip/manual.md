# manual
# gm / programming language
# version 1.0 beta
----------------------------
Example Output: output ("Content");
mathematical calculation: output (1000 + 1000);
# Example code
used: gm
used: gm.gui
window gui = 400 / 400
    gui.button.name
    if click = output ("click button");
#  premier
// of

/*
premier
*/

# grammar
1.  function
variable (a)
    output ("Hello, world!") // variable code
a()
2. Output
output ("Content");
3. Calculation
+, -, *, /, $
4. sound
sound(path)
# Practice
We're developing a compilation program
----------------------------
gm name.gm